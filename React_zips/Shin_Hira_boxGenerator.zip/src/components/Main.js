import React, { useState } from 'react';
import Form from './Form.js';
import Box from './Box.js';

const Main = () => {
  const [colorList, setColorList] = useState([]);

  const addColor = (newColor) => {
    // setColorList(colorList.push(newColor));
    console.log(newColor);
    setColorList([...colorList, newColor]);
    console.log(colorList);
  }

  return (
    <div>
      <Form addColor={addColor}/>
      <Box colorList={colorList}/>
    </div>
  );
}

export default Main;