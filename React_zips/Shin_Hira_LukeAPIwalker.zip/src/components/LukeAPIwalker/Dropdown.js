import React, { useState } from 'react';
import { navigate } from '@reach/router';

const Dropdown = props => {
  const category = ["films", "people", "planets", "species", "starships"];
  const [search, setSearch] = useState("people");
  const [id, setId] = useState("");

  const handleForm = (e) => {
    e.preventDefault();
    console.log(search)
    console.log(id)
    navigate('/'+search+'/'+id);
  }

  return (
    <form onSubmit={handleForm}>
      <div>
        <label>Search for: </label>
        <select value={search} onChange={e => setSearch(e.target.value)}>
          {category.map( (item, i) => {
            return <option key={i} value={item}>{item}</option>
          })}
        </select>
      </div>
      <div>
        <label>ID: </label>
        <input type="text" onChange={e => setId(e.target.value)}/>
        <button onClick={handleForm}>Search</button>
      </div>
    </form>
  )
}

export default Dropdown;