import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Dropdown from './Dropdown';

const Display = props => {
  const [result, setResult] = useState("");
  const [error, setError] = useState(false);
  const { category, id } = props;

  useEffect( () => {
    axios.get(`https://swapi.dev/api/${category}/${id}/`)
    .then(response => setResult(response.data))
    .catch(err => setError(true))
    }, [category, id]);


  return (
    <div>
      <Dropdown path="/" />
      { error === true ? <h1>These aren't the droids you're looking for.</h1>
      : category === "films" ?
        <div>
          <h4>Title: {result.title}</h4>
          <h4>Episode: {result.episode_id}</h4>
          <h4>Director: {result.director}</h4>
          <h4>Producer: {result.producer}</h4>
        </div>
      : category === "people" ?
        <div>
          <h4>Name: {result.name}</h4>
          <h4>Height: {result.height}</h4>
          <h4>Hair Color: {result.hair_color}</h4>
          <h4>Birth Year: {result.birth_year}</h4>
        </div> 
      : category === "planets" ?
        <div>
          <h4>Name: {result.name}</h4>
          <h4>Diameter: {result.diameter}</h4>
          <h4>Climate: {result.climate}</h4>
          <h4>Gravity: {result.gravity}</h4>
        </div> 
      : category === "starships" ?
        <div>
          <h4>Name: {result.name}</h4>
          <h4>Model: {result.model}</h4>
          <h4>Length: {result.length}</h4>
          <h4>Crew: {result.crew}</h4>
        </div> 
      : category === "species" ?
        <div>
          <h4>Name: {result.name}</h4>
          <h4>Classification: {result.classification}</h4>
          <h4>Designation: {result.designation}</h4>
          <h4>Average Height: {result.average_height}</h4>
        </div> 
      : <h1>Loading...</h1>
      }
    </div>
  )
}

export default Display;