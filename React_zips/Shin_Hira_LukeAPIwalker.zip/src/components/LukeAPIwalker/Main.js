import React from 'react';
import { Router } from '@reach/router';
import Dropdown from './Dropdown';
import Display from './Display';


const Main = () => {

  return (
    <Router>
      <Dropdown path="/" />
      <Display path="/:category/:id" />
    </Router>
  )
}

export default Main;