import React from 'react';

const AddTask = props => {
  const { name, onChange, onAdd } = props;

  return (
    <div>
      <input type="text" value={name} onChange={onChange}/>
      <button onClick={onAdd}>Add</button>
    </div>
  )
}

export default AddTask;