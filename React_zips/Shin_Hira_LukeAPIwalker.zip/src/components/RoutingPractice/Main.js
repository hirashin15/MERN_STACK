import React from 'react';
import { Router } from '@reach/router';
import Home from './Home';
import Param1 from './Param1';
import Param2 from './Param2'

const Main =() => {

  return (
    <Router>
      <Home path="/home" />
      <Param1 path="/:param1" />
      <Param2 path="/:word/:color1/:color2" />
    </Router>
  )
}

export default Main;