import React from 'react';

const Param1 = props => {

  return (
    <div>
      {
        isNaN(+props.param1) 
        ? <h1>The word is: {props.param1}</h1>
        : <h1>The number is: {props.param1}</h1>
      }
    </div>
  )
}

export default Param1;