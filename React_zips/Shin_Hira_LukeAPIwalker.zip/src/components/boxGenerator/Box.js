import React from 'react';

const Box = (props) => {
  const {colorList} = props;
  
  const addBox = (color, i) => {
    return <div key={i} style={{backgroundColor: color, width: '50px', height: '50px', display: 'inline-block', margin: '5px'}}></div>;
  }

  return (
    <div>
      { colorList.map(addBox) }
    </div>
  );
}

export default Box;