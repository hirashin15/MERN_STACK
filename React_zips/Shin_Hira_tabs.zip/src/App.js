
import './App.css';
import Main from './components/tabs/Main.js';

function App() {
  return (
    <div className="App">
      <Main/>
    </div>
  );
}

export default App;
