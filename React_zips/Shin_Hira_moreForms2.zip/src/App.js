import React, {useState} from 'react';
// import PersonCard from './components/PersonCard.js';
// import PersonCard2 from './components/BigInversion.js';
import User from './components/HookForm.js';
import Results from './components/HookFormResult.js';

function App() {
  const [state, setState] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: ""
  });
  return (
    <div className="App">
      <User input={state} setInput={setState}/>
      {/* <Results data={state}/> */}
    </div>
  );
}

export default App;
