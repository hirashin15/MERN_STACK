import React, { useState } from 'react';

const User = (props) => {
  const { input, setInput } = props;
  const [ error, setError ] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: ""
  });

  const createUser = e => {
    setInput({
      ...input,
      [e.target.name]: e.target.value
    });
    if(e.target.name == "firstName") {
      if(e.target.value.length < 2 ){
        setError({...error, firstName: "First name must be at least 2 characters long"});
      } else {
        setError({...error, firstName: ""});
      }
    }
    if(e.target.name == "lastName") {
      if(e.target.value.length < 2 ){
        setError({...error, lastName: "Last name must be at least 2 characters long"});
      } else {
        setError({...error, lastName: ""});
      }
    }
    if(e.target.name == "email") {
      if(e.target.value.length < 5 ){
        setError({...error, email: "Email must be at least 5 characters long"});
      } else {
        setError({...error, email: ""});
      }
    }
    if(e.target.name == "password") {
      if(e.target.value.length < 8 ){
        setError({...error, password: "Password must be at least 8 characters long"});
      } else {
        setError({...error, password: ""});
      }
    }
    if(e.target.name == "confirmPassword") {
      if(e.target.value !== input.password ){
        setError({...error, confirmPassword: "Passwords must match"});
      } else {
        setError({...error, confirmPassword: ""});
      }
    }
  }

  return(
    <form onSubmit={createUser}>
      <div className="form-group">
        <label>First Name: </label>
        <input type="text" name="firstName" onChange={createUser}/>
        { error.firstName ? <p style={{color:'red'}}>{ error.firstName }</p> : ""}
      </div>
      <div className="form-group">
        <label>Last Name: </label>
        <input type="text" onChange={createUser} name="lastName"/>
        { error.lastName ? <p style={{color:'red'}}>{ error.lastName }</p> : ""}
      </div>
      <div className="form-group">
        <label>email: </label>
        <input type="text" onChange={createUser} name="email"/>
        { error.email ? <p style={{color:'red'}}>{ error.email }</p> : ""}
      </div>
      <div className="form-group">
        <label>Password: </label>
        <input type="password" onChange={createUser} name="password"/>
        { error.password ? <p style={{color:'red'}}>{ error.password }</p> : ""}
      </div>
      <div className="form-group">
        <label>Confirm Password: </label>
        <input type="password" onChange={createUser} name="confirmPassword"/>
        { error.confirmPassword ? <p style={{color:'red'}}>{ error.confirmPassword }</p> : ""}
      </div>
    </form>
  );
}

export default User;