import React from 'react';

const User = (props) => {
  const { input, setInput } = props;

  const createUser = e => {
    e.preventDefault();
    setInput({
      ...input,
      [e.target.name]: e.target.value
    });
  }

  return(
    <form onSubmit={createUser}>
      <div className="form-group">
        <label>First Name: </label>
        <input type="text" onChange={createUser} name="firstName"/>
      </div>
      <div className="form-group">
        <label>Last Name: </label>
        <input type="text" onChange={createUser} name="lastName"/>
      </div>
      <div className="form-group">
        <label>email: </label>
        <input type="text" onChange={createUser} name="email"/>
      </div>
      <div className="form-group">
        <label>Password: </label>
        <input type="password" onChange={createUser} name="password"/>
      </div>
      <div className="form-group">
        <label>Confirm Password: </label>
        <input type="password" onChange={createUser} name="confirmPassword"/>
      </div>
    </form>
  );
}

export default User;