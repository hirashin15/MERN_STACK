import React, { useState } from 'react';

const Form = props => {
  const [input, setInput] = useState("");

  const onSubmit = (e) => {
    e.preventDefault();
    props.addColor( input );
  }

  return (
    <div>
      <form onSubmit={onSubmit}>
        <label>Color <input type="text" name="color" onChange={e => setInput(e.target.value)} value={ input }/></label>
        <input type="submit" value="Add" />
      </form>
    </div>
  )
}

export default Form;