import React from 'react';

const Display = props => {
  const { tabInfo } = props;

  const func = () => console.log({tabInfo});

  return (
    <div style={{width: "400px", height: "500px", display: "flex", justifyContent: "center", border: "1px solid black", margin: "0 auto"}}>
      <h5>Where the info goes: { tabInfo }</h5>
      {func()}
    </div>
  );
}

export default Display;