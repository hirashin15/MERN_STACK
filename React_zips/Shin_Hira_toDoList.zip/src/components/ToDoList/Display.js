import React from 'react';

const Display = props => {
  const { list, handleChecked, handleDelete } = props;

  return (
    <div>
      {
        list.map( (task) => {
          return (
            <div>
              <input type="checkbox" checked={task.isComplete} onChange={() => handleChecked(task.id)}/>
              <h4 key={task.id} 
                  style={{
                    textDecoration: task.isComplete 
                    ? 'line-through'
                    : 'none'
                  }}>
                  {task.name}
              </h4> 
            </div>
          )}
        )
      }
      <button onClick={handleDelete}>Delete Completed</button>
    </div>
  )
}

export default Display;