import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Pokemon = props => {
  const [pokemon, setPokemon] = useState([]);
  
  // useEffect( () => {
  //   fetch('https://pokeapi.co/api/v2/pokemon/')
  //     .then(response => response.json())
  //     .then(response => setPokemon(response.results))
  // }, []);

  useEffect( () => {
    axios.get('https://pokeapi.co/api/v2/pokemon/')
      .then(response => setPokemon(response.data.results))
      
  }, []);

  function clickHandler() {
    props.fillList(pokemon);
  }

  return (
    <div>
      <button onClick={e => clickHandler()}>Fetch Pokemon</button>
    </div>
  )
}

export default Pokemon;