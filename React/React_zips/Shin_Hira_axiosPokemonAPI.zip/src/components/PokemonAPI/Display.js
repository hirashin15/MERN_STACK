import React from 'react';

const Display = props => {
  
  return (
    <div>
      {props.list.map( (pokemon, index) =>
        {return (<h4 key={index}>{pokemon.name}</h4>)}
      )}
    </div>
  )
}

export default Display;