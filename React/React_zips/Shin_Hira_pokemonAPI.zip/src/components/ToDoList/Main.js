import React, { useState } from 'react';

import AddTask from './AddTask';
import Display from './Display';

const Main = () => {
  const [list, setList] = useState([]);
  const [name, setName] = useState(""); 

  function handleChange(e) {
    setName(e.target.value);
  }

  function handleAdd() {
    const newList = list.concat({ name, id: '', isComplete: false});
    const listWithId = newList.map( (task, i) => {
      return {...task, id: i};
    });
    setList(listWithId);
    setName('');
  }

  function handleChecked(id) {
    const updateList = list.map((task) => {
      if(task.id === id) {
        const updateTask = {
          ...task,
          isComplete: !task.isComplete 
        };
        return updateTask;
      }
      return task;
    })
    setList(updateList);
  }

  function handleDelete() {
    const deleteList = list.filter(task => task.isComplete === false);
    setList(deleteList);
  }

  return (
    <div>
      <AddTask name={name} onChange={handleChange} onAdd={handleAdd} />
      <Display list={list} handleChecked={handleChecked} handleDelete={handleDelete}/>
    </div>
  )
}

export default Main;