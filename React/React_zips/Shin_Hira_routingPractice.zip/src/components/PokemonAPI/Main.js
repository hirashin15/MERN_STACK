import React, { useState } from 'react';
import Pokemon from './Pokemon';
import Display from './Display';

const Main = () => {
  const [listOfPokemon, setListOfPokemon] = useState([]);

  const fillList = (pokemon) => {
    setListOfPokemon(pokemon);
  }
  
  return (
    <div>
      <Pokemon fillList={fillList}/>
      <Display list={listOfPokemon}/>
    </div>
  )
}

export default Main;
