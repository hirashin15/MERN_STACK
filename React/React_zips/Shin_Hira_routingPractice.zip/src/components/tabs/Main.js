import React, { useState } from 'react';
import Tab from './Tab.js';
import Display from './Display.js';

const Main = () => {
  // const itemList =
  //   [{label: "Tab 1", content: "Tab 1 content here"},
  //   {label: "Tab 2", content: "Tab 2 content here"},
  //   {label: "Tab 3", content: "Tab 3 content here"}];
  const [tabInfo, setTabInfo] = useState("");

  const content = (item) => {
    setTabInfo(item);
  }

  return (
    <div>
      <Tab itemList={itemList} content={content}/>
      <Display tabInfo={tabInfo} setInfo={setTabInfo}/>
    </div>
  );
}

export default Main;