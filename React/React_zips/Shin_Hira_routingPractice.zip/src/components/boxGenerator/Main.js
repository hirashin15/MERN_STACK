import React, { useState } from 'react';
import Form from './Form.js';
import Box from './Box.js';

const Main = () => {
  const [colorList, setColorList] = useState([]);

  const addColor = (newColor) => {
    setColorList([...colorList, newColor]);
  }

  return (
    <div>
      <Form addColor={addColor}/>
      <Box colorList={colorList}/>
    </div>
  );
}

export default Main;