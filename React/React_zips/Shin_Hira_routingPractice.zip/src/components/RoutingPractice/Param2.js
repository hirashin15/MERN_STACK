import React from 'react';

const Param2 = props => {

  return (
    <div style={{background: props.color2}}>
      {
        isNaN(+props.word) 
        ? <h1 style={{color: props.color1}}>The word is: {props.word}</h1>
        : <h1 style={{color: props.color1}}>The number is: {props.word}</h1>
      }

    </div>
  )
}

export default Param2;