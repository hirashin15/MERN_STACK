import React, { useState } from 'react';

const User = (props) => {
  const { input, setInput } = props;
  const [ error, setError ] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: ""
  });

  const createUser = e => {
    setInput({
      ...input,
      [e.target.name]: e.target.value
    });
  }

  const handleFirst = (e) => {
    setInput({firstName: e.target.value});
    if(e.target.value.length < 2 ){
      setError({firstName: "First name must be at least 2 characters long"});
    } else {
      setError({firstName: ""});
    }
  }

  const handleLast = (e) => {
    setInput({lastName: e.target.value});
    if(e.target.value.length < 2 ){
      setError({lastName: "Last name must be at least 2 characters long"});
    } else {
      setError({lastName: ""});
    }
  }

  const handleEmail = (e) => {
    setInput({email: e.target.value});
    if(e.target.value.length < 5 ){
      setError({email: "Email must be at least 5 characters long"});
    } else {
      setError({email: ""});
    }
  }

  const handlePassword = (e) => {
    setInput({password: e.target.value});
    if(e.target.value.length < 8 ){
      setError({password: "Password must be at least 8 characters long"});
    } else {
      setError({password: ""});
    }
  }

  const handleConfirmPassword = (e) => {
    setInput({confirmPassword: e.target.value});
    console.log(input.password);
    console.log(e.target.value);
    if(input.confirmPassword !== input.password ){
      setError({confirmPassword: "Passwords must match"});
    } else {
      setError({confirmPassword: ""});
    }
  }

  return(
    <form onSubmit={createUser}>
      <div className="form-group">
        <label>First Name: </label>
        <input type="text" name="firstName" onChange={handleFirst}/>
        <p style={{color:'red'}}>{ error.firstName }</p>
      </div>
      <div className="form-group">
        <label>Last Name: </label>
        <input type="text" onChange={handleLast} name="lastName"/>
        <p style={{color:'red'}}>{ error.lastName }</p>
      </div>
      <div className="form-group">
        <label>email: </label>
        <input type="text" onChange={handleEmail} name="email"/>
        <p style={{color:'red'}}>{ error.email }</p>
      </div>
      <div className="form-group">
        <label>Password: </label>
        <input type="password" onChange={handlePassword} name="password"/>
        <p style={{color:'red'}}>{ error.password }</p>
      </div>
      <div className="form-group">
        <label>Confirm Password: </label>
        <input type="password" onChange={handleConfirmPassword} name="confirmPassword"/>
        <p style={{color:'red'}}>{ error.confirmPassword }</p>
      </div>
    </form>
  );
}

export default User;